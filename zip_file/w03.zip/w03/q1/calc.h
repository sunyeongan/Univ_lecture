int add(a,b);
int sub(a,b);
int mul(a,b);

